const Discord = require("discord.js");

exports.run = async (client, message, args) => {
    message.reply("Creating tickets using this bot has been deprecated. Please use the `/open` command on <@748317979971682385>.");
};
