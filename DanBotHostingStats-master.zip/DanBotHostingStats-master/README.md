# DBH Pterodactyl Bot
This bot manages user creation, server creation and general management of Pterodactyl via Discord.

## Maintainers
- **Dan**
    - Email: dan@danbot.host
    - GitHub: [danielpmc](https://github.com/danielpmc)
- **DIBSTER**
    - Email: dibster@danbot.host
    - GitHub: [DEV-DIBSTER](https://github.com/DEV-DIBSTER)
- **William**
    - Email: william@danbot.host
    - GitHub: [wdhdev](https://github.com/wdhdev)
